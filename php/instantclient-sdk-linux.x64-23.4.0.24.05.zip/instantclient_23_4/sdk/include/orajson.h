/* Copyright (c) 2018, Oracle and/or its affiliates. All rights reserved.*/
 
/* 
   NAME 
     orajson.h - Oracle JSON APIs 

   FILE DESCRIPTION 


*/

#ifndef ORAJSON_ORACLE
# define ORAJSON_ORACLE

#ifndef JZNOTN_ORACLE
# include <jznotn.h>
#endif

#endif                                              /* ORAJSON_ORACLE */
